# All Video Downloader APK
Web downloader video TikTok (no watermark), Instagram Reels/IGTV, YouTube HD.
Siap deploy ke Vercel.

## Cara deploy
1. Upload folder ke GitHub.
2. Login ke https://vercel.com/ lewat HP atau PC.
3. Klik New Project → Import Git Repository → Deploy.
4. Buka link hasil deploy → masukkan link video → download otomatis.
