import axios from 'axios';
import ytdl from 'ytdl-core';

export default async function handler(req, res) {
  const videoUrl = req.query.url;
  if(!videoUrl) return res.status(400).send("Masukkan link video");

  try {
    let filename = 'video.mp4';

    if(videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')){
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      ytdl(videoUrl, { quality: 'highestvideo' }).pipe(res);
      return;
    }

    if(videoUrl.includes('tiktok.com')){
      const tiktokApi = `https://api.tikmate.app/api/lookup?url=${encodeURIComponent(videoUrl)}`;
      const tiktokRes = await axios.get(tiktokApi);
      const videoLink = tiktokRes.data.video_no_watermark;
      if(!videoLink) return res.status(500).send("Gagal dapatkan video TikTok");
      const videoStream = await axios.get(videoLink, { responseType: 'stream' });
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      videoStream.data.pipe(res);
      return;
    }

    if(videoUrl.includes('instagram.com')){
      const instaApi = `https://api.instadlapi.com/v1/?url=${encodeURIComponent(videoUrl)}`;
      const instaRes = await axios.get(instaApi);
      const videoLink = instaRes.data.video;
      if(!videoLink) return res.status(500).send("Gagal dapatkan video Instagram");
      const videoStream = await axios.get(videoLink, { responseType: 'stream' });
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      videoStream.data.pipe(res);
      return;
    }

    res.status(400).send("Platform tidak didukung");
  } catch(err) {
    console.error(err);
    res.status(500).send("Terjadi kesalahan saat download");
  }
}